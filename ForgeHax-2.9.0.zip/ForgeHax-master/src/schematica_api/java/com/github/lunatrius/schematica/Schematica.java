package com.github.lunatrius.schematica;

import com.github.lunatrius.schematica.proxy.CommonProxy;

public class Schematica {
    public static CommonProxy proxy;
}
