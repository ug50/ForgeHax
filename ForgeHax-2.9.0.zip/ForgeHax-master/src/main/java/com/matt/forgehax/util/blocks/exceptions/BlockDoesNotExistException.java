package com.matt.forgehax.util.blocks.exceptions;

/**
 * Created on 5/15/2017 by fr1kin
 */
public class BlockDoesNotExistException extends Exception {
  
  public BlockDoesNotExistException(String msg) {
    super(msg);
  }
}
