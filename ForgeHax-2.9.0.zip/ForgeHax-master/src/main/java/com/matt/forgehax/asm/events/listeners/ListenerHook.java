package com.matt.forgehax.asm.events.listeners;

/**
 * Created on 2/11/2018 by fr1kin
 */
public interface ListenerHook {

}
