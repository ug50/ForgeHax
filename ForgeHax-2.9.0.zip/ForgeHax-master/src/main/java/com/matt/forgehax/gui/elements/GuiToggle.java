package com.matt.forgehax.gui.elements;

/**
 * Created by Babbaj on 9/5/2017.
 */
/*public class GuiToggle extends GuiElement {

    public GuiToggle(Setting settingIn) {
        super.setSetting(settingIn);
        height = 12;
    }
}*/
