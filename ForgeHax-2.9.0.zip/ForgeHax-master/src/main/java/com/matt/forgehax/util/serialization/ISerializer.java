package com.matt.forgehax.util.serialization;

/**
 * Created on 6/4/2017 by fr1kin
 */
public interface ISerializer {
  
  void serialize();
  
  void deserialize();
}
