package com.matt.forgehax.asm.utils.transforming;

/**
 * Created on 5/4/2017 by fr1kin
 */
public enum InjectPriority {
  HIGHEST,
  HIGH,
  DEFAULT,
  LOW,
  LOWEST,
  ;
}
