package com.matt.forgehax.util;

/**
 * Created on 6/27/2017 by fr1kin
 */
public class TickrateCounter {
  
  private static double tr = 0.D;
  
  public static double getTickrate() {
    return 0.D;
  }
  
  public static void setTickrate(double tickrate) {
    tr = tickrate;
  }
}
