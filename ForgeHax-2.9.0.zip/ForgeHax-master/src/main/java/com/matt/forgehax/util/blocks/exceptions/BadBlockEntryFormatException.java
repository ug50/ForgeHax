package com.matt.forgehax.util.blocks.exceptions;

/**
 * Created on 5/19/2017 by fr1kin
 */
public class BadBlockEntryFormatException extends Exception {
  
  public BadBlockEntryFormatException() {
    super();
  }
}
