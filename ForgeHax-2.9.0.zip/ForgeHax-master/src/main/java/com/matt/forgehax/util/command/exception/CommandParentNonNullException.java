package com.matt.forgehax.util.command.exception;

/**
 * Created on 6/3/2017 by fr1kin
 */
public class CommandParentNonNullException extends RuntimeException {
  
  public CommandParentNonNullException(String msg) {
    super(msg);
  }
}
