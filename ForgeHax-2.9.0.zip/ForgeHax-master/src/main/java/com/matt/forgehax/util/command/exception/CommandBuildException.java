package com.matt.forgehax.util.command.exception;

/**
 * Created on 6/6/2017 by fr1kin
 */
public class CommandBuildException extends RuntimeException {
  
  public CommandBuildException(String message, Throwable cause) {
    super(message, cause);
  }
}
