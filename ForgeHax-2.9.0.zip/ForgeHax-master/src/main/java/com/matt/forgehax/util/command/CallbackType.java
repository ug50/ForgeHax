package com.matt.forgehax.util.command;

/**
 * Created on 6/2/2017 by fr1kin
 */
public enum CallbackType {
  SUCCESS,
  FAILURE,
  KEY_PRESSED,
  KEY_DOWN,
  CHANGE,
  ;
}
